<div class="footer-containter">
<div class="container">
<div class="row">
<div class="col-lg-4">
<div class="footer-logo">
<a href="index.php"><img src="../img/footer-logo.webp" alt="logo" title="logo"></a>
</div>
</div>
<div class="col-lg-3 footer_link_show">
<div class="footer-links">
<ul>
<li class="active">소개</li>
<li><a href="heritage_value.php" target="_parent">역사 & 가치</a></li>
<li><a href="leadership_management.php" target="_parent">리더십 & 경영</a></li>
</ul>
</div>
</div>
<div class="col-lg-3 footer_link_show">
<div class="footer-links">
<ul>
<li class="active">비지니스 벤처</li>
<li><a href="business_strategy.php" target="_parent">비지니스 전략.</a></li>
<li><a href="business_verticals.php" target="_parent">비지니스 사업 분야</a></li>
</ul>
</div>
<div class="footer-sub-links">
<ul>
<li><a href="footwear.php" target="_parent">신발</a></li>
<li><a href="apparel_accessories.php" target="_parent">의류 & 액세서리</a></li>
<li><a href="materials.php" target="_parent">재료</a></li>
<li><a href="supply_chain_solution.php" target="_parent">공급망 솔루션</a></li>
</ul>
</div>
</div>
<div class="col-lg-2 footer_link_show">
<div class="footer-links">
<ul>
<li><a href="investor_relations.php" target="_parent" class="active">투자자 관계</a></li>
</ul>
</div>
<div class="footer-links">
<ul>
<li><a href="sustainability.php" target="_parent" class="active">지속가능성</a></li>
</ul>
</div>
<div class="footer-links">
<ul>
<li><a href="newsroom.php" target="_parent" class="active">뉴스룸</a></li>
</ul>
</div>
<div class="footer-links">
<ul>
<li><a href="careers.php" target="_parent" class="active">채용</a></li>
</ul>
</div>
<div class="footer-links">
<ul>
<li><a href="contact.php" target="_parent" class="active">연락처</a></li>
</ul>
</div>
</div>
</div>
<div class="row">
<div class="col-lg-4">
<div class="copyright">
<h6>COPYRIGHT HWASEUNG Enterprise. ALL RIGHTS RESERVED.</h6>
</div>
</div>
<div class="col-md-3">
<div class="family-site">
                <div class="accordion accordion-flush" id="faqlist">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                            Family Sites
                            </button>
                        </h2>
                        <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                            <div class="accordion-body">
                                
                            </div>
                        </div>
                    </div>
                </div>
</div>
</div>
<div class="col-md-3">
<div class="footer-icons">
<ul>
<li><a href="javascript:void(0)" target="_blank"><img src="../img/fb.webp" width="27px" height="27px"></a></li>
<li><a href="javascript:void(0)" target="_blank"><img src="../img/linkedin.webp" width="28px" height="28px"></a></li>
<!--<li><a href="javascript:void(0)" target="_blank"><img src="img/insta.png" width="28px" height="28px"></a></li>
<li><a href="javascript:void(0)" target="_blank"><img src="img/talk.png" width="28px" height="28px"></a></li>-->
<ul>
</div>
</div>
</div>
</div>
</div>