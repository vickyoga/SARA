<?php
/*
if($_SERVER)

{

	$dbcon1 = mysqli_connect("localhost","lafsvapp_admin","Admin@54321","lafsvapp_admin") or die("localhost connection failed ");

}

else

{
*/
	//$dbcon1 = mysqli_connect("localhost","hse_user","(JFBN5gXL~ED","hse_admin") or die("localhost connection failed ");
	$dbcon1 = mysqli_connect("localhost","root","","hse_admin1") or die("localhost connection failed ");

//}



?>