		<div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<div class="copyright">
							<p>© <span>2022</span> <a href="buy.html" class="transition">Tradecars</a> All rights reserved.</p>
						</div>
					</div>
				</div>
			</div>
		</div>