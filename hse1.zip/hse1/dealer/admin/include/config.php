<?php
/*
if($_SERVER)

{

	$dbcon1 = mysqli_connect("localhost","lafsvapp_admin","Admin@54321","lafsvapp_admin") or die("localhost connection failed ");

}

else

{
*/
	//$dbcon1 = mysqli_connect("localhost","lafsvapp_admin","Admin@54321","lafsvapp_admin") or die("localhost connection failed ");
	$dbcon1 = mysqli_connect("localhost","root","","tradecar_beta") or die("localhost connection failed ");

//}



?>