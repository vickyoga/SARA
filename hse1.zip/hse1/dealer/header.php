<div class="nav-fixed-header">
<nav class="navbar navbar-expand-sm menu-bg navbar-light">
  <div class="container">
    <a class="navbar-brand" href="index.php"><div class="logo"><img src="img/logo.jpg" class="img-fluid"></div></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
      <ul class="navbar-nav">
	  <li class="nav-item">
	  <li class="nav-item">
          <a class="nav-link text-dark" href="sell-my-car-for-cash-today.php">SELL MY CAR</a>
		   </li>
          <a class="nav-link text-dark" href="best-site-to-buy-used-cars.php">USED CARS</a>
		   </li>	   
		   <li class="nav-item">
          <a class="nav-link text-dark" href="buy-here-pay-here-car-dealerships.php">CAR DEALERS</a>
		   </li>
		   <li class="nav-item">
          <a class="nav-link text-dark" href="vehicle-history-report.php">CAR HISTORY REPORTS</a>
		   </li>
	      <li class="nav-item">
          <a class="nav-link text-dark" href="#"><i class="fa-solid fa-phone"></i> +1 (888) 594-2334</a>
		   </li>
          <li class="nav-item">
          <a class="nav-link text-dark" href="#"><i class="fab fa-facebook-f"></i></a>
		   </li> 
		   <li class="nav-item">
		  <a class="nav-link text-dark" href="#"><i class="fa-brands fa-linkedin-in"></i></a>
        </li>
		<li class="nav-item">
		  <a class="nav-link text-dark" href="#"><i class="fab fa-instagram"></i></a>
		   </li> 
		<li class="nav-item">
		  <a class="nav-link text-dark" href="#"><i class="fab fa-twitter"></i></a>
        </li>  
      </ul>
    </div>
  </div>
</nav>
</div>